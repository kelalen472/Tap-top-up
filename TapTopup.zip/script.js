// script.js
const pricing = {...}; // trimmed for brevity